This program is Free. But, if someone wants to make 
a small donation for this project. Others Countries, 
donation (one US dollar) => US$ 1  Thank you !
Brazil Bank, Agency: 3148-8, Checking account: 13.233-0 
=================================================
Este programa é totalmente grátis. 
Porém, para dar continuidade a este PROJETO.
E se alguém puder e quiser ajudá-lo, poderá DOAR 
uma pequena quantia simbólica de : Um Real R$ 1,00 
Banco do Brasil - Agencia: 3148-8 - Cta.-corrente: 13.233-0
Agradeço desde já qualquer ajuda.
